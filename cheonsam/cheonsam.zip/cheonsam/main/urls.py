from django.urls import path
from main.views import *

urlpatterns = [
    path('banner/', get_banner),
    path('order/', order_view),
    path('speices/', get_species),
    path('info/', get_info),
    path('info2/', get_info_2),
    path('company/', get_company),
    path('question/', get_question),
    path('manual/', get_manual),
    path('facts/', get_facts),
    path('feedback/', get_feedback),
]