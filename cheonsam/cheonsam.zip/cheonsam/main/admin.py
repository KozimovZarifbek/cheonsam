from django.contrib import admin
from .models import *

admin.site.register(Banner)
admin.site.register(Species)
admin.site.register(Company)
admin.site.register(Order)
admin.site.register(Info)
admin.site.register(Info_2)
admin.site.register(Question)
admin.site.register(Manual)
admin.site.register(Facts)
admin.site.register(Feedback)
